File: README.txt 

This is from the compressed bin archive of the https://github.com/bsenftner/ffvideo project.

The compressed zip archive this file is included within needs a file added before the application
can be used. The file: shape_predictor_68_face_landmarks.dat is from the Dlib library. It should 
be downloaded, decompressed and added to the executable directory. This file can be downloaded from

http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2

Once uncomprssed, place into the executable directory. 


